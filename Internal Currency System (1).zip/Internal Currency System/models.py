"""
Models - Data Models
Internal Currency Mining System
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import List
from datetime import datetime


class AbsenceType(Enum):
    """Attendance status for a student on a given day."""
    PRESENT = "present"
    ABSENT = "absent"
    MEDICAL = "medical"


@dataclass
class ActivityRecord:
    """Raw parsed activity record for a single student-day."""
    student_id: str
    hostname: str
    date: str
    total_hours: float
    active_hours: float
    attendance: AbsenceType
    helped_others: bool = False
    self_learning: bool = False
    project_on_time: bool = False
    project_early: bool = False
    flagged_apps: List[str] = field(default_factory=list)


@dataclass
class StudentScore:
    """Computed score breakdown for a single student-day."""
    student_id: str
    name: str
    date: str
    base_pts: float
    attend_bonus: float
    activity_bonus: float
    beh_bonus: float
    penalty: float
    total_pts: float
    grade: str
    active_hours: float


@dataclass
class WeeklyReport:
    """Aggregated report for one week across all students."""
    week_ending: str
    students: List[StudentScore] = field(default_factory=list)
    generated_at: str = field(default_factory=lambda: datetime.now().isoformat())
