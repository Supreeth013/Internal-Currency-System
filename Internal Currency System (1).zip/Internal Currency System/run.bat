@echo off
python -X utf8 serve.py
pause
