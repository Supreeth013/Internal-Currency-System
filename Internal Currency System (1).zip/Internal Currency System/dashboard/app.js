/* ================================================================
   MiningOS Dashboard — App Logic
   ================================================================ */

(() => {
    "use strict";

    // ---- DOM refs --------------------------------------------------
    const $ = (sel) => document.querySelector(sel);
    const dropZone      = $("#drop-zone");
    const fileInput      = $("#file-input");
    const weekPicker     = $("#week-picker");
    const processBtn     = $("#process-btn");
    const uploadStatus   = $("#upload-status");
    const selectedFileEl = $("#selected-file");
    const lastUpdatedEl  = $("#last-updated");

    const valStudents = $("#val-students");
    const valPoints   = $("#val-points");
    const valWeeks    = $("#val-weeks");
    const valTop      = $("#val-top");

    const leaderboardBody = $("#leaderboard-body");
    const modal           = $("#student-modal");
    const modalClose      = $("#modal-close");
    const modalName       = $("#modal-name");
    const modalBody       = $("#modal-body");

    let breakdownChart = null;
    let trendChart     = null;
    let cachedData     = null;
    let selectedFile   = null;

    // ---- Helpers ---------------------------------------------------
    function setDefaultWeek() {
        const now = new Date();
        const day = now.getDay();
        const diff = (5 - day + 7) % 7 || 7;
        const friday = new Date(now);
        friday.setDate(now.getDate() + diff);
        weekPicker.value = friday.toISOString().slice(0, 10);
    }

    function showStatus(msg, type) {
        uploadStatus.textContent = msg;
        uploadStatus.className = "status-bar " + type;
        uploadStatus.classList.remove("hidden");
    }

    function hideStatus() { uploadStatus.classList.add("hidden"); }

    // ---- Upload Zone -----------------------------------------------
    dropZone.addEventListener("click", () => fileInput.click());
    dropZone.addEventListener("dragover",  (e) => { e.preventDefault(); dropZone.classList.add("drag-over"); });
    dropZone.addEventListener("dragleave", ()  => dropZone.classList.remove("drag-over"));
    dropZone.addEventListener("drop", (e) => {
        e.preventDefault();
        dropZone.classList.remove("drag-over");
        if (e.dataTransfer.files.length) {
            selectedFile = e.dataTransfer.files[0];
            onFileSelected();
        }
    });
    fileInput.addEventListener("change", () => {
        if (fileInput.files.length) {
            selectedFile = fileInput.files[0];
            onFileSelected();
        }
    });

    function onFileSelected() {
        selectedFileEl.textContent = "📄 " + selectedFile.name;
        selectedFileEl.classList.remove("hidden");
        processBtn.disabled = false;
        hideStatus();
    }

    // ---- Process ---------------------------------------------------
    processBtn.addEventListener("click", async () => {
        if (!selectedFile) return;
        processBtn.disabled = true;
        showStatus("⏳ Processing pipeline…", "loading");

        const form = new FormData();
        form.append("file", selectedFile);
        form.append("week", weekPicker.value);

        try {
            const res  = await fetch("/upload", { method: "POST", body: form });
            const data = await res.json();

            if (res.ok) {
                showStatus("✅ " + data.message, "success");
                await loadResults();
            } else {
                showStatus("❌ " + (data.message || data.error), "error");
            }
        } catch (err) {
            showStatus("❌ Network error: " + err.message, "error");
        }

        processBtn.disabled = false;
    });

    // ---- Load Results ----------------------------------------------
    async function loadResults() {
        try {
            const res  = await fetch("/results");
            const data = await res.json();
            cachedData = data;
            renderAll(data);
        } catch (err) {
            console.error("Failed to load results:", err);
        }
    }

    // ---- Render All ------------------------------------------------
    function renderAll(data) {
        const totals = data.totals || [];
        const weeks  = data.weeks  || {};
        const weekKeys = Object.keys(weeks).sort();

        // Stats
        valStudents.textContent = totals.length;
        valPoints.textContent   = totals.reduce((s, t) => s + t.total_pts, 0).toFixed(0);
        valWeeks.textContent    = weekKeys.length;
        valTop.textContent      = totals.length ? totals[0].name : "—";

        // Last updated
        if (data.last_updated) {
            const d = new Date(data.last_updated);
            lastUpdatedEl.textContent = "Last updated: " + d.toLocaleString();
        }

        renderLeaderboard(totals, weeks);
        renderBreakdownChart(totals, weeks, weekKeys);
        renderTrendChart(totals, weeks, weekKeys);
        renderBonusSummary(totals, weeks, weekKeys);
    }

    // ---- Leaderboard -----------------------------------------------
    const medals = { 1: "🥇", 2: "🥈", 3: "🥉" };

    function renderLeaderboard(totals, weeks) {
        if (!totals.length) {
            leaderboardBody.innerHTML = '<tr><td colspan="6" class="empty-row">No data yet — upload an export to get started</td></tr>';
            return;
        }

        // Check latest week for exempt/bonus status
        const weekKeys = Object.keys(weeks).sort();
        const latestStudents = weekKeys.length ? (weeks[weekKeys[weekKeys.length - 1]]?.students || []) : [];

        leaderboardBody.innerHTML = totals.map((t) => {
            const medal = medals[t.rank] || t.rank;
            const latestEntry = latestStudents.find(s => s.student_id === t.student_id);
            const isExempt = latestEntry && latestEntry.grade === "Exempt";
            const hasBonus = latestEntry && latestEntry.beh_bonus > 0;

            let badgeClass, badgeText;
            if (isExempt) {
                badgeClass = "badge-exempt";
                badgeText = "Exempt";
            } else if (t.total_pts >= 50) {
                badgeClass = "badge-active";
                badgeText = "Active";
            } else if (t.total_pts >= 20) {
                badgeClass = "badge-warning";
                badgeText = "Moderate";
            } else {
                badgeClass = "badge-danger";
                badgeText = "Low";
            }

            const bonusIcon = hasBonus ? ' <span class="bonus-tag" title="Bonus earned">⭐</span>' : '';

            return `<tr data-sid="${t.student_id}">
                <td><span class="rank-medal">${medal}</span></td>
                <td>${t.name}${bonusIcon}</td>
                <td>${t.total_active_hours.toFixed(1)}h</td>
                <td><strong>${t.total_pts.toFixed(1)}</strong></td>
                <td>${t.weeks_present}</td>
                <td><span class="status-badge ${badgeClass}">${badgeText}</span></td>
            </tr>`;
        }).join("");

        // Row click → modal
        leaderboardBody.querySelectorAll("tr[data-sid]").forEach((row) => {
            row.addEventListener("click", () => openModal(row.dataset.sid));
        });
    }

    // ---- Points Breakdown Chart ------------------------------------
    function renderBreakdownChart(totals, weeks, weekKeys) {
        if (!weekKeys.length) return;

        const latestWeek = weekKeys[weekKeys.length - 1];
        const students = weeks[latestWeek]?.students || [];

        const labels  = students.map((s) => s.name);
        const base    = students.map((s) => s.base_pts);
        const attend  = students.map((s) => s.attend_bonus);
        const activity = students.map((s) => s.activity_bonus);
        const beh     = students.map((s) => s.beh_bonus);
        const penalty = students.map((s) => Math.abs(s.penalty));

        const ctx = $("#breakdown-chart").getContext("2d");
        if (breakdownChart) breakdownChart.destroy();

        breakdownChart = new Chart(ctx, {
            type: "bar",
            data: {
                labels,
                datasets: [
                    { label: "Base",       data: base,     backgroundColor: "#58A6FF" },
                    { label: "Attendance", data: attend,   backgroundColor: "#1D9E75" },
                    { label: "Activity",   data: activity, backgroundColor: "#3FB950" },
                    { label: "Behaviour",  data: beh,      backgroundColor: "#D2A8FF" },
                    { label: "Penalty",    data: penalty,  backgroundColor: "#F85149" },
                ],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: "bottom", labels: { color: "#8B949E", font: { family: "Inter" } } },
                },
                scales: {
                    x: { stacked: true,  ticks: { color: "#8B949E", font: { family: "Inter" } }, grid: { color: "rgba(48,54,61,0.4)" } },
                    y: { stacked: true, ticks: { color: "#8B949E", font: { family: "Inter" } }, grid: { color: "rgba(48,54,61,0.4)" } },
                },
            },
        });
    }

    // ---- Weekly Trend Chart ----------------------------------------
    const lineColors = ["#58A6FF", "#1D9E75", "#D2A8FF", "#F0883E", "#3FB950", "#F85149"];

    function renderTrendChart(totals, weeks, weekKeys) {
        if (weekKeys.length < 1) return;

        // Build cumulative per-student across weeks
        const studentIds = totals.map((t) => t.student_id);
        const datasets = studentIds.map((sid, i) => {
            let cumulative = 0;
            const data = weekKeys.map((wk) => {
                const stu = (weeks[wk]?.students || []).find((s) => s.student_id === sid);
                cumulative += stu ? stu.total_pts : 0;
                return cumulative;
            });
            const name = totals.find((t) => t.student_id === sid)?.name || sid;
            return {
                label: name,
                data,
                borderColor: lineColors[i % lineColors.length],
                backgroundColor: lineColors[i % lineColors.length] + "22",
                tension: 0.3,
                fill: false,
                pointRadius: 4,
                pointHoverRadius: 6,
            };
        });

        const ctx = $("#trend-chart").getContext("2d");
        if (trendChart) trendChart.destroy();

        trendChart = new Chart(ctx, {
            type: "line",
            data: { labels: weekKeys, datasets },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: "bottom", labels: { color: "#8B949E", font: { family: "Inter" } } },
                },
                scales: {
                    x: { ticks: { color: "#8B949E", font: { family: "Inter" } }, grid: { color: "rgba(48,54,61,0.4)" } },
                    y: { ticks: { color: "#8B949E", font: { family: "Inter" } }, grid: { color: "rgba(48,54,61,0.4)" } },
                },
            },
        });
    }

    // ---- Bonus Summary (injected after charts) ---------------------
    function renderBonusSummary(totals, weeks, weekKeys) {
        const existing = document.getElementById("bonus-summary-section");
        if (existing) existing.remove();

        if (!weekKeys.length) return;
        const latestWeek = weekKeys[weekKeys.length - 1];
        const students = weeks[latestWeek]?.students || [];

        const bonusStudents = students.filter(s => s.beh_bonus > 0);
        const exemptStudents = students.filter(s => s.grade === "Exempt");

        if (!bonusStudents.length && !exemptStudents.length) return;

        let html = '<section id="bonus-summary-section" class="card" style="margin-top:1.5rem">';
        html += '<h2 class="section-title">🎯 Bonus & Exemption Summary</h2>';
        html += '<div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem">';

        // Bonus column
        html += '<div>';
        html += '<h3 style="font-size:0.9rem; color:var(--accent); margin-bottom:0.5rem">⭐ Behavioural Bonuses</h3>';
        if (bonusStudents.length) {
            bonusStudents.forEach(s => {
                html += `<div style="padding:0.4rem 0; border-bottom:1px solid var(--border); font-size:0.85rem">`;
                html += `<strong>${s.name}</strong> <span class="detail-value positive">+${s.beh_bonus} pts</span>`;
                html += `</div>`;
            });
        } else {
            html += '<p style="color:var(--text-muted); font-size:0.85rem">No bonuses this week</p>';
        }
        html += '</div>';

        // Exempt column
        html += '<div>';
        html += '<h3 style="font-size:0.9rem; color:#58A6FF; margin-bottom:0.5rem">🏥 Medical Exemptions</h3>';
        if (exemptStudents.length) {
            exemptStudents.forEach(s => {
                html += `<div style="padding:0.4rem 0; border-bottom:1px solid var(--border); font-size:0.85rem">`;
                html += `<strong>${s.name}</strong> <span class="status-badge badge-exempt">Exempt</span>`;
                html += `</div>`;
            });
        } else {
            html += '<p style="color:var(--text-muted); font-size:0.85rem">No exemptions this week</p>';
        }
        html += '</div>';

        html += '</div></section>';

        const chartsRow = document.querySelector(".charts-row");
        if (chartsRow) chartsRow.insertAdjacentHTML("afterend", html);
    }

    // ---- Student Modal ---------------------------------------------
    function openModal(sid) {
        if (!cachedData) return;

        const totals = cachedData.totals || [];
        const weeks  = cachedData.weeks  || {};
        const weekKeys = Object.keys(weeks).sort();
        const student = totals.find((t) => t.student_id === sid);
        if (!student) return;

        modalName.textContent = student.name;

        // Aggregate details from all weeks
        let html = `
            <div class="detail-row"><span class="detail-label">Rank</span><span class="detail-value">#${student.rank}</span></div>
            <div class="detail-row"><span class="detail-label">Total Points</span><span class="detail-value positive">${student.total_pts}</span></div>
            <div class="detail-row"><span class="detail-label">Total Active Hours</span><span class="detail-value">${student.total_active_hours.toFixed(1)}h</span></div>
            <div class="detail-row"><span class="detail-label">Weeks Present</span><span class="detail-value">${student.weeks_present}</span></div>
            <hr style="border-color:var(--border); margin:0.75rem 0">
            <h3 style="font-size:0.95rem; margin-bottom:0.5rem;">Weekly Breakdown</h3>
        `;

        weekKeys.forEach((wk) => {
            const stu = (weeks[wk]?.students || []).find((s) => s.student_id === sid);
            if (!stu) return;
            const isExemptWeek = stu.grade === "Exempt";
            const weekBorder = isExemptWeek ? "border-left:3px solid #58A6FF;" : stu.beh_bonus > 0 ? "border-left:3px solid var(--accent);" : "";
            html += `
                <div style="margin-bottom:0.6rem; padding:0.5rem; background:var(--bg); border-radius:var(--radius-sm); ${weekBorder}">
                    <div style="font-weight:600; margin-bottom:0.3rem;">📅 ${wk}
                        ${isExemptWeek ? '<span class="status-badge badge-exempt" style="margin-left:0.5rem">Medical Exempt</span>' : ''}
                        ${stu.beh_bonus > 0 ? `<span class="bonus-tag" style="margin-left:0.5rem">⭐ +${stu.beh_bonus} bonus</span>` : ''}
                    </div>
                    ${isExemptWeek ? '<div class="detail-row"><span class="detail-label">Status</span><span class="detail-value" style="color:#58A6FF">Medically Exempt — 0 pts, no penalty</span></div>' : `
                    <div class="detail-row"><span class="detail-label">Base</span><span class="detail-value">${stu.base_pts}</span></div>
                    <div class="detail-row"><span class="detail-label">Attendance</span><span class="detail-value positive">+${stu.attend_bonus}</span></div>
                    <div class="detail-row"><span class="detail-label">Activity</span><span class="detail-value positive">+${stu.activity_bonus}</span></div>
                    <div class="detail-row"><span class="detail-label">Behaviour</span><span class="detail-value ${stu.beh_bonus > 0 ? 'positive' : ''}">${stu.beh_bonus > 0 ? '+' : ''}${stu.beh_bonus}</span></div>
                    <div class="detail-row"><span class="detail-label">Penalty</span><span class="detail-value ${stu.penalty < 0 ? 'negative' : ''}">${stu.penalty}</span></div>
                    <div class="detail-row"><span class="detail-label">Total</span><span class="detail-value" style="font-size:1.05rem;">${stu.total_pts}</span></div>
                    <div class="detail-row"><span class="detail-label">Grade</span><span class="detail-value">${stu.grade}</span></div>
                    ${stu.flagged_apps?.length ? `<div class="detail-row"><span class="detail-label">⚠ Flagged</span><span class="detail-value negative">${stu.flagged_apps.join(", ")}</span></div>` : ''}
                    `}
                </div>
            `;
        });

        modalBody.innerHTML = html;
        modal.classList.remove("hidden");
    }

    modalClose.addEventListener("click", () => modal.classList.add("hidden"));
    modal.addEventListener("click", (e) => { if (e.target === modal) modal.classList.add("hidden"); });

    // ---- Init ------------------------------------------------------
    setDefaultWeek();
    loadResults();
})();
