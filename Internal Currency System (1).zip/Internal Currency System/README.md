# ⛏️ Nucleus — Internal Currency Mining System

> An automated, agent-based pipeline that converts ActivityWatch screen-time data into an internal currency leaderboard — built by **Team 7** for the Nucleus ecosystem.

---

## 📋 Table of Contents

- [Project Title](#-project-title)
- [Team Members](#-team-members)
- [Project Description](#-project-description)
- [Architecture](#-architecture)
- [Scoring Rules](#-scoring-rules)
- [Agent Breakdown](#-agent-breakdown)
- [Project Structure](#-project-structure)
- [Setup & Installation](#-setup--installation)
- [Usage](#-usage)
- [Dashboard](#-dashboard)
- [Configuration](#-configuration)
- [API Endpoints](#-api-endpoints)
- [Data Source](#-data-source)
- [Tech Stack](#-tech-stack)
- [Key Features](#-key-features)
- [Troubleshooting](#-troubleshooting)

---

## 🏷️ Project Title

**Nucleus — Activity-Based Internal Currency Mining System**

---

## 👥 Team Members

| # | Name | Hostname ID |
|---|------|-------------|
| 1 | Sumukh S P | `sumukhsp` |
| 2 | Harikrishna A | `harikrishna` |
| 3 | Supreeth | `supreeth` |
| 4 | Pruthvi | `pruthvi` |
| 5 | Vaishnavi Shinde | `vaishnavi` |
| 6 | Sukeerti | `sukeerti` |

---

## 📝 Project Description

An automated agent-based pipeline that:

1. **Reads** ActivityWatch JSON exports from student laptops every Friday
2. **Extracts** active hours (only `not-afk` time counts — idle/AFK is excluded)
3. **Assigns** base points at **1 coin per active hour**
4. **Applies** bonus points for peer help, self-learning, and project delivery
5. **Enforces** attendance rules with medical exemptions and absence penalties
6. **Publishes** a live leaderboard dashboard with charts and student breakdowns
7. **Pushes** results to Team 8's Nucleus API every Friday

The system is designed as a modular, 6-agent pipeline where each agent handles one specific concern — making it easy to modify scoring rules, add new bonus categories, or swap out data sources.

---

## 🏗️ Architecture

```
                    ┌──────────────────────────────────┐
                    │     ActivityWatch JSON Exports    │
                    │         (data/input/*.json)       │
                    └──────────────┬───────────────────┘
                                   │
                                   ▼
┌─────────────────────────────────────────────────────────────────┐
│                        PIPELINE (pipeline.py)                   │
│                                                                 │
│  ┌──────────────┐   ┌──────────────┐   ┌───────────────────┐   │
│  │ 1. AW Parser │──▶│ 2. Base Pts  │──▶│ 3. Bonus Pts      │   │
│  │  (raw JSON)  │   │  (1pt/hr)    │   │  (behaviour flags)│   │
│  └──────────────┘   └──────────────┘   └────────┬──────────┘   │
│                                                  │              │
│  ┌──────────────┐   ┌──────────────┐   ┌────────▼──────────┐   │
│  │ 6. Nucleus   │◀──│ 5. Aggregate │◀──│ 4. Attendance     │   │
│  │    Push      │   │  (leaderboard│   │  (medical/penalty)│   │
│  └──────────────┘   └──────────────┘   └───────────────────┘   │
│                              │                                  │
└──────────────────────────────┼──────────────────────────────────┘
                               │
              ┌────────────────┼────────────────┐
              ▼                ▼                ▼
     scores_*.json    leaderboard_       report_*.csv
                      cumulative.json
              │                │                │
              └────────────────┼────────────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │  Flask Server :8765  │
                    │   (serve.py)         │
                    └──────────┬──────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │  Web Dashboard      │
                    │  (dashboard/)       │
                    └─────────────────────┘
```

---

## 💰 Scoring Rules

All point values are configurable in `config/scoring_config.json`.

### Base Points

| Rule | Points | Condition |
|------|--------|-----------|
| Active Hour Coin | **+1 pt/hr** | Per active (not-afk) hour logged |

### Attendance

| Rule | Points | Condition |
|------|--------|-----------|
| Attendance Bonus | **+20 pts** | Active hours ≥ 3h in a day |
| Below Minimum | **0** | Active < 3h → no attendance bonus |
| Medical Exemption | **0 pts** | Listed in `medical_exceptions.json` → no penalty |
| Unexcused Absence | **−20 pts** | Absent with no medical exception |

### Activity Ratio Bonus

| Level | Points | Condition |
|-------|--------|-----------|
| HIGH | **+20 pts** | `active_hours / total_hours` > 80% |
| MEDIUM | **+10 pts** | Ratio between 60%–80% |
| LOW | **0** | Ratio below 60% |

### Behavioural Bonus

| Behaviour | Points | Notes |
|-----------|--------|-------|
| Helped Others | **+15 pts** | Peer collaboration flag |
| Self Learning | **+10 pts** | Independent learning flag |
| Project On Time | **+20 pts** | Delivered project on deadline |
| Project Early | **+30 pts** | Delivered early — **overrides** Project On Time |

### Grade Ladder

| Grade | Active Hours Required |
|-------|----------------------|
| A | 5h+ |
| B | 3h+ |
| C | 2h+ |
| D | 1h+ |
| E | Below 1h |

---

## 🤖 Agent Breakdown

### 1. AW Raw Parser (`agents/aw_raw_parser.py`)

- Parses real ActivityWatch JSON bucket exports
- **Only `not-afk` events count** — AFK duration is tracked but excluded from scoring
- Converts all UTC timestamps to **IST (UTC+5:30)**
- Groups events by IST calendar date
- Extracts hostname from bucket IDs (`aw-watcher-afk_HOSTNAME` → `HOSTNAME`)
- Filters idle system apps: `explorer.exe`, `ShellHost.exe`, `SearchHost.exe`, `PickerHost.exe`, `ApplicationFrameHost.exe`
- Flags non-work apps: `VALORANT-Win64-Shipping.exe`, `vlc.exe`, `Antigravity.exe`
- Supports `--week` filter for Monday–Friday processing windows

### 2. Parser Agent (`agents/parser_agent.py`)

- Bridges raw AW parser output into `ActivityRecord` data models
- Determines attendance status using medical exceptions and active hours
- Merges weekly behavioural bonus flags from `bonus_input.json`

### 3. Base Points Agent (`agents/base_points_agent.py`)

- Calculates `active_hours × pts_per_active_hour` (1 pt/hr)
- Applies attendance bonus (+20) when active ≥ 3h
- Applies activity ratio bonus (+20 HIGH / +10 MEDIUM)
- Absent unexcused → 0 base points
- Medical → 0 base points, no penalty
- Assigns letter grade (A–E)

### 4. Bonus Points Agent (`agents/bonus_points_agent.py`)

- Reads `data/input/bonus_input.json` for weekly behavioural flags
- Applies configurable bonuses per student hostname
- `project_early` **overrides** `project_on_time` (not additive)
- Missing file or unknown hostname → defaults to false, prints warning, never crashes

### 5. Attendance Agent (`agents/attendance_agent.py`)

- Reads `data/input/medical_exceptions.json`
- Medical exception → 0 pts, no penalty, grade marked `Exempt`
- Absent with no exception → applies `unexcused_penalty` (−20)
- Present but below `min_hours_for_attendance` → strips attendance bonus
- Prints formatted attendance summary (exempted / penalised / normal)
- Missing file → silently skips exemption check

### 6. Aggregator Agent (`agents/aggregator_agent.py`)

- Merges all student scores into a ranked leaderboard
- Saves `data/output/scores_YYYY-MM-DD.json` (weekly snapshot)
- Updates `data/output/leaderboard_cumulative.json` (running total across all weeks — never overwrites old data)
- Exports `data/output/report_YYYY-MM-DD.csv` with full score breakdown
- Prints console leaderboard with 🥇🥈🥉 medals

### 7. Nucleus Push Agent (`agents/nucleus_push_agent.py`)

- Reads `leaderboard_cumulative.json`
- POSTs to URL configured in `scoring_config.json` → `nucleus_api_url`
- Payload includes `week_ending`, `processed_by`, `pipeline_version`, and student scores
- Empty URL or failed POST → logs warning and skips gracefully
- Never crashes the pipeline

---

## 📁 Project Structure

```
Internal Currency System/
├── pipeline.py                    # Main pipeline entry point
├── serve.py                       # Flask server (port 8765)
├── models.py                      # Dataclasses & AbsenceType enum
├── requirements.txt               # Python dependencies
├── run.bat                        # Windows launcher (UTF-8 mode)
├── .gitignore                     # Ignores caches, data files, secrets
├── README.md                      # This file
│
├── agents/                        # Pipeline agents
│   ├── aw_raw_parser.py           # ActivityWatch JSON parser (AFK-aware)
│   ├── parser_agent.py            # Raw → ActivityRecord bridge
│   ├── base_points_agent.py       # Base scoring (1pt/hr + bonuses)
│   ├── bonus_points_agent.py      # Behavioural bonus applicator
│   ├── attendance_agent.py        # Medical exemptions & penalties
│   ├── aggregator_agent.py        # Leaderboard, JSON, CSV export
│   └── nucleus_push_agent.py      # POST to Nucleus API
│
├── config/                        # Configuration files
│   ├── scoring_config.json        # All point values & thresholds
│   └── students.json              # Hostname → display name mapping
│
├── data/
│   ├── input/                     # Drop AW exports here
│   │   ├── bonus_input.json       # Weekly behavioural flags
│   │   ├── medical_exceptions.json # Medical absence entries
│   │   └── *.json                 # ActivityWatch export files
│   └── output/                    # Generated reports
│       ├── scores_*.json          # Weekly score snapshots
│       ├── leaderboard_cumulative.json  # Running totals
│       └── report_*.csv           # Weekly CSV reports
│
└── dashboard/                     # Web frontend
    ├── index.html                 # Dashboard page
    ├── styles.css                 # Dark theme styling
    └── app.js                     # Charts, upload, leaderboard logic
```

---

## ⚙️ Setup & Installation

### Prerequisites

- Python 3.10+
- pip

### Steps

```bash
# 1. Clone the repository
git clone <repo-url>
cd "Internal Currency System"

# 2. Install dependencies
pip install -r requirements.txt
```

### Dependencies

```
flask, pandas, openpyxl, requests, tqdm,
google-auth, google-auth-oauthlib,
google-api-python-client, python-dotenv
```

---

## 🚀 Usage

### Option A: Run the pipeline manually

```bash
# Process all exports in data/input/ for a specific week
python -X utf8 pipeline.py --week 2026-05-09

# Process a single file
python -X utf8 pipeline.py --week 2026-05-09 --input data/input/export.json

# Process from a custom folder
python -X utf8 pipeline.py --week 2026-05-09 --folder path/to/exports/
```

> **Note:** Use `-X utf8` on Windows to avoid encoding errors with emoji output.

### Option B: Use the web dashboard

```bash
# Start the Flask server
python -X utf8 serve.py

# Or double-click
run.bat
```

Then open **http://localhost:8765** in your browser.

### Option C: Weekly workflow (every Friday)

1. Collect ActivityWatch JSON exports from each student's laptop
2. Drop all `.json` files into `data/input/`
3. Edit `data/input/bonus_input.json` — set behavioural flags for the week
4. Edit `data/input/medical_exceptions.json` — add any medical absences
5. Run `python -X utf8 pipeline.py --week YYYY-MM-DD` or use the dashboard
6. Review the leaderboard and CSV report in `data/output/`

---

## 📊 Dashboard

The web dashboard runs at `http://localhost:8765` with a dark theme (`#0D1117` background, `#1D9E75` accent green).

### Features

| Section | Description |
|---------|-------------|
| **Header** | MiningOS logo, version badge, last updated timestamp, NUCLEUS badge |
| **Upload Zone** | Drag & drop JSON upload + week date picker + Process button |
| **Stat Cards** | Total Students, Points Distributed, Weeks Processed, Top Earner |
| **Leaderboard** | Ranked table with 🥇🥈🥉 medals, active hours, total points, status badges |
| **Points Breakdown** | Stacked bar chart — Base, Attendance, Activity, Behaviour, Penalty (Chart.js) |
| **Weekly Trend** | Cumulative line chart tracking each student's points across weeks |
| **Student Modal** | Click any student row for a full weekly-by-weekly score breakdown |

### How the upload works

1. Drag-drop or select a JSON file
2. Pick the week-ending Friday date
3. Click **Process File**
4. The server saves the file, runs the **full pipeline** against **all** files in `data/input/`, and returns results
5. Dashboard auto-refreshes with the updated leaderboard

---

## 🔧 Configuration

### `config/scoring_config.json`

```json
{
  "pts_per_active_hour": 1,
  "attendance_bonus": 20,
  "high_activity_bonus": 20,
  "medium_activity_bonus": 10,
  "helped_peer_bonus": 15,
  "self_learning_bonus": 10,
  "project_ontime_bonus": 20,
  "project_early_bonus": 30,
  "unexcused_penalty": -20,
  "high_activity_threshold": 0.80,
  "medium_activity_threshold": 0.60,
  "min_hours_for_attendance": 3,
  "nucleus_api_url": ""
}
```

### `config/students.json`

Maps ActivityWatch hostnames to display names:

```json
{
  "sumukhsp": "Sumukh S P",
  "harikrishna": "Harikrishna A",
  "supreeth": "Supreeth",
  "pruthvi": "Pruthvi",
  "vaishnavi": "Vaishnavi Shinde",
  "sukeerti": "Sukeerti"
}
```

### `data/input/bonus_input.json`

Weekly behavioural flags — edit before each pipeline run:

```json
{
  "week": "2026-05-09",
  "students": [
    {
      "hostname": "sumukhsp",
      "helped_others": false,
      "self_learning": true,
      "project_on_time": true,
      "project_early": false
    }
  ]
}
```

### `data/input/medical_exceptions.json`

Medical absence entries — students listed here receive 0 points with no penalty:

```json
{
  "exceptions": [
    {
      "hostname": "sumukhsp",
      "date": "2026-05-05",
      "reason": "fever"
    }
  ]
}
```

---

## 🌐 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/` | Serves the dashboard (`index.html`) |
| `POST` | `/upload` | Upload a JSON file + `week` param → saves file, runs full pipeline, returns results |
| `GET` | `/results` | Returns `leaderboard_cumulative.json` as JSON |
| `GET` | `/report` | Downloads the latest weekly CSV report |

### POST /upload

```bash
curl -X POST http://localhost:8765/upload \
  -F "file=@export.json" \
  -F "week=2026-05-09"
```

**Response:**
```json
{
  "status": "success",
  "message": "Pipeline completed for week 2026-05-09 — 7 file(s) processed",
  "file": "export.json",
  "total_files": 7,
  "week": "2026-05-09"
}
```

---

## 📡 Data Source

**ActivityWatch** — an open-source, privacy-first time tracker installed on each student's laptop.

- Tracks active window titles, app names, and AFK status
- Exports as JSON containing `aw-watcher-window` and `aw-watcher-afk` buckets
- Students export their data every Friday for processing
- Only `not-afk` events contribute to active hours — idle time is excluded

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|------------|
| **Backend** | Python 3.11, Flask |
| **Frontend** | HTML5, CSS3, JavaScript (vanilla) |
| **Charts** | Chart.js 4.x |
| **Data Processing** | Python dataclasses, JSON, CSV |
| **Time Tracking** | ActivityWatch |
| **API Integration** | Nucleus API (Team 8), Google Drive API |
| **Dependencies** | pandas, requests, openpyxl, tqdm, python-dotenv |

---

## ✨ Key Features

- ✅ Parses real ActivityWatch JSON exports automatically
- ✅ Only active hours count (`not-afk` time) — idle/AFK is excluded
- ✅ 7-agent modular pipeline with error isolation
- ✅ Live web dashboard with leaderboard, charts, and student modals
- ✅ Medical exemption handling for absences (no penalty)
- ✅ Flags non-work apps (gaming, media players)
- ✅ `project_early` overrides `project_on_time` (not additive)
- ✅ Auto-detects correct week from data if selected week has no matches
- ✅ Processes ALL input files together — no data replacement on upload
- ✅ Cumulative JSON preserves all historical weeks
- ✅ Exports weekly CSV and JSON reports
- ✅ Integrates with Team 8 Nucleus API every Friday
- ✅ Never crashes — every agent handles errors gracefully

---

## 🔍 Troubleshooting

| Issue | Solution |
|-------|----------|
| `UnicodeEncodeError` on Windows | Use `python -X utf8` or run via `run.bat` |
| Dashboard shows 0 after upload | The week date may not match your data — the pipeline auto-detects the correct week |
| Only 1 student shows after multiple uploads | Fixed in v1.0 — the server now processes ALL files in `data/input/` together |
| `bonus_input.json` not found warning | Create the file or ignore — all bonuses default to false |
| Medical exceptions file missing | Silently skipped — no warning, no crash |
| Nucleus push skipped | Set `nucleus_api_url` in `scoring_config.json` to enable |

---

## 📄 License

Internal project — Team 7, Nucleus System.

---

*Built with ⛏️ by Team 7 for the Nucleus Internal Currency Ecosystem*
