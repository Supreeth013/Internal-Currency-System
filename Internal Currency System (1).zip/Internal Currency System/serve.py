"""
Serve — Flask Web Server
=========================
- Serves dashboard at http://localhost:8765
- POST /upload: accept JSON, save to data/input/, run pipeline
- GET  /results: return leaderboard_cumulative.json
- GET  /report:  return latest weekly CSV
- Upload limit: 64 MB
"""

import json
import glob
import os
import traceback
from pathlib import Path
from datetime import datetime, timedelta

from flask import Flask, request, jsonify, send_from_directory, send_file

from pipeline import run_pipeline

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

BASE = Path(__file__).resolve().parent
DASHBOARD = BASE / "dashboard"
INPUT_DIR = BASE / "data" / "input"
OUTPUT_DIR = BASE / "data" / "output"

# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

app = Flask(__name__, static_folder=str(DASHBOARD))
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024 * 1024  # 64 MB


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------


@app.route("/")
def index():
    return send_from_directory(str(DASHBOARD), "index.html")


@app.route("/<path:filename>")
def static_files(filename):
    return send_from_directory(str(DASHBOARD), filename)


# ---------------------------------------------------------------------------
# Upload + pipeline
# ---------------------------------------------------------------------------


@app.route("/upload", methods=["POST"])
def upload():
    """Accept a JSON file, save it, and run the full pipeline."""
    if "file" not in request.files:
        return jsonify({"error": "No file part in request"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    # Week parameter
    week = request.form.get("week", "")
    if not week:
        # Default to this coming Friday
        today = datetime.now()
        days_until_friday = (4 - today.weekday()) % 7
        if days_until_friday == 0 and today.hour >= 18:
            days_until_friday = 7
        friday = today + timedelta(days=days_until_friday)
        week = friday.strftime("%Y-%m-%d")

    # Save file
    INPUT_DIR.mkdir(parents=True, exist_ok=True)
    save_path = INPUT_DIR / file.filename
    file.save(str(save_path))

    # Collect ALL AW export files in input folder
    skip = {"bonus_input.json", "medical_exceptions.json"}
    all_files = sorted(
        str(f) for f in INPUT_DIR.glob("*.json")
        if f.name not in skip
    )

    # Run pipeline with ALL files so every student is included
    try:
        run_pipeline(week, all_files)
        return jsonify({
            "status": "success",
            "message": f"Pipeline completed for week {week} — {len(all_files)} file(s) processed",
            "file": file.filename,
            "total_files": len(all_files),
            "week": week,
        })
    except Exception as exc:
        traceback.print_exc()
        return jsonify({
            "status": "error",
            "message": str(exc),
        }), 500


# ---------------------------------------------------------------------------
# Results API
# ---------------------------------------------------------------------------


@app.route("/results")
def results():
    """Return leaderboard_cumulative.json."""
    cum_path = OUTPUT_DIR / "leaderboard_cumulative.json"
    if not cum_path.exists():
        return jsonify({"weeks": {}, "totals": []})
    return jsonify(json.loads(cum_path.read_text(encoding="utf-8")))


@app.route("/report")
def report():
    """Return the latest weekly CSV report."""
    csvs = sorted(glob.glob(str(OUTPUT_DIR / "report_*.csv")))
    if not csvs:
        return jsonify({"error": "No reports available"}), 404
    return send_file(csvs[-1], mimetype="text/csv", as_attachment=True)


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("\n  🌐 Dashboard: http://localhost:8765\n")
    app.run(host="0.0.0.0", port=8765, debug=True)
