"""
Parser Agent
=============
Bridges aw_raw_parser output into ActivityRecord model objects.
Determines attendance status using min_hours_for_attendance config
and medical_exceptions.json.
"""

import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from models import ActivityRecord, AbsenceType
from agents.aw_raw_parser import parse_aw_export

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

_CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "scoring_config.json"
_MEDICAL_INPUT = (
    Path(__file__).resolve().parent.parent / "data" / "input" / "medical_exceptions.json"
)
_BONUS_INPUT = (
    Path(__file__).resolve().parent.parent / "data" / "input" / "bonus_input.json"
)

# ---------------------------------------------------------------------------
# Loaders
# ---------------------------------------------------------------------------


def _load_config() -> Dict:
    return json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))


def _load_medical_dates() -> set:
    """Return a set of (hostname, date) tuples with medical exceptions."""
    if not _MEDICAL_INPUT.exists():
        return set()
    try:
        raw = json.loads(_MEDICAL_INPUT.read_text(encoding="utf-8"))
        return {
            (e["hostname"], e["date"])
            for e in raw.get("exceptions", [])
        }
    except (json.JSONDecodeError, KeyError):
        return set()


def _load_bonus_flags() -> Dict[str, Dict[str, bool]]:
    """Return bonus flags keyed by hostname."""
    if not _BONUS_INPUT.exists():
        return {}
    try:
        raw = json.loads(_BONUS_INPUT.read_text(encoding="utf-8"))
        return {
            s["hostname"]: s for s in raw.get("students", [])
        }
    except (json.JSONDecodeError, KeyError):
        return {}


# ---------------------------------------------------------------------------
# Core
# ---------------------------------------------------------------------------


def parse_file(
    filepath: str,
    week: Optional[str] = None,
) -> Tuple[List[ActivityRecord], Dict[str, List[str]]]:
    """
    Parse one AW export and return (records, flagged_map).

    Parameters
    ----------
    filepath : str
        Path to the AW JSON export.
    week : str | None
        Optional week filter (YYYY-MM-DD).

    Returns
    -------
    records : list[ActivityRecord]
    flagged_map : dict  { student_id: [flagged_apps] }
    """
    cfg = _load_config()
    medical_dates = _load_medical_dates()
    bonus_flags = _load_bonus_flags()

    result = parse_aw_export(filepath, week=week)
    hostname = result["hostname"]
    student_id = hostname.lower()

    records: List[ActivityRecord] = []
    flagged_map: Dict[str, List[str]] = {}

    # Collect bonus flags for this student
    stu_bonus = bonus_flags.get(student_id, {})

    for day in result["days"]:
        date = day["date"]

        # Determine attendance
        if (student_id, date) in medical_dates:
            attendance = AbsenceType.MEDICAL
        elif day["active_hours"] <= 0:
            attendance = AbsenceType.ABSENT
        else:
            attendance = AbsenceType.PRESENT

        record = ActivityRecord(
            student_id=student_id,
            hostname=hostname,
            date=date,
            total_hours=day["total_hours"],
            active_hours=day["active_hours"],
            attendance=attendance,
            helped_others=stu_bonus.get("helped_others", False),
            self_learning=stu_bonus.get("self_learning", False),
            project_on_time=stu_bonus.get("project_on_time", False),
            project_early=stu_bonus.get("project_early", False),
            flagged_apps=day.get("flagged_apps", []),
        )
        records.append(record)

        if day.get("flagged_apps"):
            flagged_map[student_id] = day["flagged_apps"]

    return records, flagged_map
