"""
Base Points Agent
=================
Calculates base mining points for a single ActivityRecord.
All weights / thresholds are read from config/scoring_config.json.

Scoring rules
-------------
- 1 pt per active hour (configurable via pts_per_active_hour)
- +attendance_bonus   if active_hours >= min_hours_for_attendance
- +high_activity_bonus  if active/total ratio > high_activity_threshold
- +medium_activity_bonus if ratio is between medium and high thresholds
- Absent unexcused → 0 base points
- Medical → 0 base points, no penalty

Grade ladder
------------
A = 5 h+   B = 3 h+   C = 2 h+   D = 1 h+   E = below 1 h
"""

import json
from pathlib import Path
from typing import Dict

from models import ActivityRecord, StudentScore, AbsenceType

# ---------------------------------------------------------------------------
# Config loader
# ---------------------------------------------------------------------------

_CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "scoring_config.json"
_STUDENTS_PATH = Path(__file__).resolve().parent.parent / "config" / "students.json"


def _load_config() -> Dict:
    return json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))


def _load_students() -> Dict[str, str]:
    return json.loads(_STUDENTS_PATH.read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# Grade assignment
# ---------------------------------------------------------------------------

def _assign_grade(active_hours: float) -> str:
    """Map active hours to a letter grade."""
    if active_hours >= 5:
        return "A"
    if active_hours >= 3:
        return "B"
    if active_hours >= 2:
        return "C"
    if active_hours >= 1:
        return "D"
    return "E"


# ---------------------------------------------------------------------------
# Core scoring
# ---------------------------------------------------------------------------

def calculate_base_score(record: ActivityRecord) -> StudentScore:
    """
    Compute base points + attendance/activity bonuses for one student-day.

    Parameters
    ----------
    record : ActivityRecord
        Parsed activity record for a single day.

    Returns
    -------
    StudentScore
        Score breakdown (bonus fields left at 0 for downstream agents).
    """
    cfg = _load_config()
    students = _load_students()

    name = students.get(record.student_id, record.student_id)

    # -- Absent unexcused → zero everything, apply penalty later ----------
    if record.attendance == AbsenceType.ABSENT:
        return StudentScore(
            student_id=record.student_id,
            name=name,
            date=record.date,
            base_pts=0,
            attend_bonus=0,
            activity_bonus=0,
            beh_bonus=0,
            penalty=0,            # penalty agent handles this
            total_pts=0,
            grade="E",
            active_hours=0,
        )

    # -- Medical → zero points, no penalty --------------------------------
    if record.attendance == AbsenceType.MEDICAL:
        return StudentScore(
            student_id=record.student_id,
            name=name,
            date=record.date,
            base_pts=0,
            attend_bonus=0,
            activity_bonus=0,
            beh_bonus=0,
            penalty=0,
            total_pts=0,
            grade="E",
            active_hours=0,
        )

    # -- Present → calculate normally -------------------------------------
    pts_per_hour = cfg["pts_per_active_hour"]
    base_pts = round(record.active_hours * pts_per_hour, 2)

    # Attendance bonus
    attend_bonus = 0.0
    if record.active_hours >= cfg["min_hours_for_attendance"]:
        attend_bonus = cfg["attendance_bonus"]

    # Activity ratio bonus
    activity_bonus = 0.0
    if record.total_hours > 0:
        ratio = record.active_hours / record.total_hours
        if ratio >= cfg["high_activity_threshold"]:
            activity_bonus = cfg["high_activity_bonus"]
        elif ratio >= cfg["medium_activity_threshold"]:
            activity_bonus = cfg["medium_activity_bonus"]

    total = base_pts + attend_bonus + activity_bonus
    grade = _assign_grade(record.active_hours)

    return StudentScore(
        student_id=record.student_id,
        name=name,
        date=record.date,
        base_pts=base_pts,
        attend_bonus=attend_bonus,
        activity_bonus=activity_bonus,
        beh_bonus=0,              # filled by bonus_points_agent
        penalty=0,                # filled by attendance_agent
        total_pts=round(total, 2),
        grade=grade,
        active_hours=record.active_hours,
    )


# ---------------------------------------------------------------------------
# Batch helper
# ---------------------------------------------------------------------------

def score_all(records: list) -> list:
    """Score a list of ActivityRecords and return a list of StudentScores."""
    return [calculate_base_score(r) for r in records]


# ---------------------------------------------------------------------------
# CLI quick-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    demo = ActivityRecord(
        student_id="sumukhsp",
        hostname="SUMUKH-PC",
        date="2026-05-08",
        total_hours=6.0,
        active_hours=5.2,
        attendance=AbsenceType.PRESENT,
    )
    score = calculate_base_score(demo)
    print(f"{score.name} | {score.date}")
    print(f"  Base     : {score.base_pts}")
    print(f"  Attend   : {score.attend_bonus}")
    print(f"  Activity : {score.activity_bonus}")
    print(f"  Total    : {score.total_pts}")
    print(f"  Grade    : {score.grade}")
