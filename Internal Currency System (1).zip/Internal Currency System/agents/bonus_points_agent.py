"""
Bonus Points Agent
==================
Reads data/input/bonus_input.json and applies behavioural bonus points
to existing StudentScore objects.

Bonus categories (all weights from scoring_config.json):
    helped_others  → +helped_peer_bonus    (15)
    self_learning  → +self_learning_bonus   (10)
    project_on_time → +project_ontime_bonus (20)
    project_early  → +project_early_bonus   (30)

If bonus_input.json is missing or malformed, all bonuses default to 0
and a warning is printed. The pipeline never crashes.
"""

import json
import warnings
from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import replace

from models import StudentScore

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

_CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "scoring_config.json"
_BONUS_INPUT = Path(__file__).resolve().parent.parent / "data" / "input" / "bonus_input.json"

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


def _load_config() -> Dict:
    return json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# Bonus data loader
# ---------------------------------------------------------------------------


def _load_bonus_data(filepath: Optional[str] = None) -> Dict[str, Dict[str, bool]]:
    """
    Load bonus flags keyed by hostname.

    Returns
    -------
    dict  { hostname: { helped_others, self_learning, … } }
    Empty dict if file is missing / unreadable.
    """
    path = Path(filepath) if filepath else _BONUS_INPUT

    if not path.exists():
        warnings.warn(
            f"[BonusAgent] bonus_input.json not found at {path}. "
            "All bonuses default to false.",
            stacklevel=2,
        )
        return {}

    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        entries = raw.get("students", [])
        return {
            s["hostname"]: {
                "helped_others": s.get("helped_others", False),
                "self_learning": s.get("self_learning", False),
                "project_on_time": s.get("project_on_time", False),
                "project_early": s.get("project_early", False),
            }
            for s in entries
        }
    except (json.JSONDecodeError, KeyError, TypeError) as exc:
        warnings.warn(
            f"[BonusAgent] Failed to parse bonus_input.json: {exc}. "
            "All bonuses default to false.",
            stacklevel=2,
        )
        return {}


# ---------------------------------------------------------------------------
# Core logic
# ---------------------------------------------------------------------------


def apply_bonus(score: StudentScore, filepath: Optional[str] = None) -> StudentScore:
    """
    Apply behavioural bonuses to a single StudentScore.

    Parameters
    ----------
    score : StudentScore
        Score computed by base_points_agent (beh_bonus should be 0).
    filepath : str | None
        Override path to bonus_input.json (for testing).

    Returns
    -------
    StudentScore with updated beh_bonus and total_pts.
    """
    cfg = _load_config()
    bonus_data = _load_bonus_data(filepath)

    flags = bonus_data.get(score.student_id, {})

    beh_bonus = 0.0

    if flags.get("helped_others", False):
        beh_bonus += cfg["helped_peer_bonus"]

    if flags.get("self_learning", False):
        beh_bonus += cfg["self_learning_bonus"]

    if flags.get("project_early", False):
        beh_bonus += cfg["project_early_bonus"]
    elif flags.get("project_on_time", False):
        beh_bonus += cfg["project_ontime_bonus"]

    new_total = round(score.total_pts + beh_bonus, 2)

    return replace(score, beh_bonus=beh_bonus, total_pts=new_total)


def apply_bonus_all(
    scores: List[StudentScore],
    filepath: Optional[str] = None,
) -> List[StudentScore]:
    """Apply bonuses to a list of StudentScores."""
    return [apply_bonus(s, filepath) for s in scores]


# ---------------------------------------------------------------------------
# CLI quick-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    from models import ActivityRecord, AbsenceType
    from agents.base_points_agent import calculate_base_score

    demo = ActivityRecord(
        student_id="sumukhsp",
        hostname="SUMUKH-PC",
        date="2026-05-08",
        total_hours=6.0,
        active_hours=5.2,
        attendance=AbsenceType.PRESENT,
        helped_others=True,
        self_learning=True,
    )
    base = calculate_base_score(demo)
    final = apply_bonus(base)

    print(f"{final.name} | {final.date}")
    print(f"  Base      : {final.base_pts}")
    print(f"  Attend    : {final.attend_bonus}")
    print(f"  Activity  : {final.activity_bonus}")
    print(f"  Behaviour : {final.beh_bonus}")
    print(f"  Total     : {final.total_pts}")
    print(f"  Grade     : {final.grade}")
