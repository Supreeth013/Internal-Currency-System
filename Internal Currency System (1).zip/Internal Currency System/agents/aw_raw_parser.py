"""
ActivityWatch Raw JSON Parser
=============================
Parses real AW exports. Only "not-afk" events count as active time.
AFK duration is tracked but excluded from scoring.

Usage:
    from agents.aw_raw_parser import parse_aw_export
    days = parse_aw_export("path/to/export.json")
    days = parse_aw_export("path/to/export.json", week="2026-05-04")
"""

import json
import argparse
from datetime import datetime, timedelta, timezone
from collections import defaultdict
from pathlib import Path
from typing import List, Dict, Optional

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

IST = timezone(timedelta(hours=5, minutes=30))

IDLE_APPS = frozenset([
    "explorer.exe",
    "ShellHost.exe",
    "SearchHost.exe",
    "PickerHost.exe",
    "ApplicationFrameHost.exe",
])

FLAGGED_APPS = frozenset([
    "VALORANT-Win64-Shipping.exe",
    "vlc.exe",
    "Antigravity.exe",
])

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _parse_ts(ts: str) -> datetime:
    """Parse an AW ISO timestamp and convert to IST."""
    # AW exports use ISO-8601; may or may not include 'Z' / offset
    ts = ts.replace("Z", "+00:00")
    dt = datetime.fromisoformat(ts)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(IST)


def _monday_of(date_str: str) -> datetime:
    """Return the Monday 00:00 IST for the ISO-week containing *date_str*."""
    d = datetime.strptime(date_str, "%Y-%m-%d")
    monday = d - timedelta(days=d.weekday())
    return monday.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=IST)


def _extract_hostname(bucket_id: str) -> str:
    """
    AW bucket IDs look like  'aw-watcher-afk_HOSTNAME'
    or 'aw-watcher-window_HOSTNAME'.  Extract the hostname part.
    """
    parts = bucket_id.rsplit("_", 1)
    return parts[-1] if len(parts) == 2 else bucket_id


# ---------------------------------------------------------------------------
# Core parser
# ---------------------------------------------------------------------------


def parse_aw_export(
    filepath: str,
    week: Optional[str] = None,
) -> Dict:
    """
    Parse an ActivityWatch JSON export file.

    Parameters
    ----------
    filepath : str
        Path to the AW JSON export.
    week : str | None
        Optional ISO date (YYYY-MM-DD) — if given, only events within
        that Monday–Friday window are included.

    Returns
    -------
    dict with keys:
        hostname  : str
        days      : list[dict]  — one entry per IST calendar date
            date          : str   (YYYY-MM-DD)
            active_hours  : float (from not-afk events only)
            afk_hours     : float
            total_hours   : float (active + afk)
            top_apps      : list[dict]  — [{app, hours}, …] sorted desc
            flagged_apps  : list[str]   — flagged apps seen that day
    """
    raw = json.loads(Path(filepath).read_text(encoding="utf-8"))

    # ------------------------------------------------------------------
    # Determine week filter window (Monday 00:00 → Friday 23:59:59 IST)
    # ------------------------------------------------------------------
    week_start = week_end = None
    if week:
        week_start = _monday_of(week)
        week_end = week_start + timedelta(days=4, hours=23, minutes=59, seconds=59)

    # ------------------------------------------------------------------
    # Walk every bucket
    # ------------------------------------------------------------------
    hostname = ""
    # Per-date accumulators
    active_secs: Dict[str, float] = defaultdict(float)
    afk_secs: Dict[str, float] = defaultdict(float)
    app_secs: Dict[str, Dict[str, float]] = defaultdict(lambda: defaultdict(float))
    flagged_by_day: Dict[str, set] = defaultdict(set)

    buckets = raw if isinstance(raw, dict) else {}
    # AW export can be {"buckets": {…}} or just {bucket_id: {…}}
    if "buckets" in buckets:
        buckets = buckets["buckets"]

    for bucket_id, bucket_data in buckets.items():
        if not hostname:
            hostname = _extract_hostname(bucket_id)

        bucket_type = bucket_data.get("type", "")
        events = bucket_data.get("events", [])

        for ev in events:
            ts = _parse_ts(ev["timestamp"])
            duration = ev.get("duration", 0)  # seconds

            # Week filter
            if week_start and (ts < week_start or ts > week_end):
                continue

            day_key = ts.strftime("%Y-%m-%d")

            # ----- AFK bucket → track afk vs not-afk -----------------
            if "afk" in bucket_type or "afk" in bucket_id:
                status = ev.get("data", {}).get("status", "")
                if status == "not-afk":
                    active_secs[day_key] += duration
                else:
                    afk_secs[day_key] += duration
                continue

            # ----- Window bucket → app usage tracking -----------------
            if "window" in bucket_type or "window" in bucket_id:
                app = ev.get("data", {}).get("app", "unknown")

                # Skip idle system apps
                if app in IDLE_APPS:
                    continue

                app_secs[day_key][app] += duration

                if app in FLAGGED_APPS:
                    flagged_by_day[day_key].add(app)
                continue

    # ------------------------------------------------------------------
    # Assemble per-day results
    # ------------------------------------------------------------------
    all_dates = sorted(set(active_secs) | set(afk_secs) | set(app_secs))

    days: List[Dict] = []
    for d in all_dates:
        act = active_secs[d]
        afk = afk_secs[d]

        # Top apps sorted by duration descending
        sorted_apps = sorted(
            app_secs[d].items(), key=lambda x: x[1], reverse=True
        )
        top_apps = [
            {"app": app, "hours": round(secs / 3600, 2)}
            for app, secs in sorted_apps[:10]
        ]

        days.append({
            "date": d,
            "active_hours": round(act / 3600, 2),
            "afk_hours": round(afk / 3600, 2),
            "total_hours": round((act + afk) / 3600, 2),
            "top_apps": top_apps,
            "flagged_apps": sorted(flagged_by_day.get(d, set())),
        })

    return {"hostname": hostname, "days": days}


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Parse ActivityWatch JSON export (AFK-aware)"
    )
    parser.add_argument("file", help="Path to AW JSON export")
    parser.add_argument(
        "--week",
        default=None,
        help="ISO date (YYYY-MM-DD) inside the target week; "
             "only Mon–Fri events are kept",
    )
    args = parser.parse_args()

    result = parse_aw_export(args.file, week=args.week)

    print(f"\nHostname : {result['hostname']}")
    print(f"Days     : {len(result['days'])}\n")

    for day in result["days"]:
        print(f"  {day['date']}  "
              f"active={day['active_hours']}h  "
              f"afk={day['afk_hours']}h  "
              f"total={day['total_hours']}h")
        if day["flagged_apps"]:
            print(f"    ⚠ Flagged: {', '.join(day['flagged_apps'])}")
        if day["top_apps"]:
            top3 = ", ".join(
                f"{a['app']} ({a['hours']}h)" for a in day["top_apps"][:3]
            )
            print(f"    Top apps: {top3}")
    print()


if __name__ == "__main__":
    main()
