"""
Nucleus Push Agent
==================
Reads leaderboard_cumulative.json and POSTs the latest week's
data to the Nucleus API endpoint configured in scoring_config.json.

If the URL is empty or the POST fails, logs a warning and returns
gracefully. Never crashes the pipeline.
"""

import json
import warnings
from pathlib import Path
from typing import Optional

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

_CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "scoring_config.json"
_CUM_PATH = Path(__file__).resolve().parent.parent / "data" / "output" / "leaderboard_cumulative.json"

# ---------------------------------------------------------------------------
# Core
# ---------------------------------------------------------------------------


def push_to_nucleus(week_ending: Optional[str] = None) -> bool:
    """
    POST the latest (or specified) week to the Nucleus API.

    Returns True if the push succeeded, False otherwise.
    """
    # --- Load config ------------------------------------------------------
    try:
        cfg = json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception as exc:
        warnings.warn(f"[NucleusPush] Cannot read config: {exc}", stacklevel=2)
        return False

    api_url = cfg.get("nucleus_api_url", "").strip()
    if not api_url:
        print("  ℹ️  [NucleusPush] nucleus_api_url is empty — skipping push.")
        return False

    # --- Load cumulative data ---------------------------------------------
    if not _CUM_PATH.exists():
        warnings.warn(
            "[NucleusPush] leaderboard_cumulative.json not found — skipping.",
            stacklevel=2,
        )
        return False

    try:
        cumulative = json.loads(_CUM_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        warnings.warn(f"[NucleusPush] Cannot read cumulative data: {exc}", stacklevel=2)
        return False

    weeks = cumulative.get("weeks", {})
    if not weeks:
        warnings.warn("[NucleusPush] No weeks found in cumulative data.", stacklevel=2)
        return False

    # Pick the requested week or the latest one
    if week_ending and week_ending in weeks:
        target_week = week_ending
    else:
        target_week = sorted(weeks.keys())[-1]

    week_data = weeks[target_week]

    # --- Build payload ----------------------------------------------------
    payload = {
        "week_ending": target_week,
        "processed_by": "Team 7 Mining System",
        "pipeline_version": "1.0",
        "students": week_data.get("students", []),
    }

    # --- POST -------------------------------------------------------------
    if not HAS_REQUESTS:
        warnings.warn(
            "[NucleusPush] 'requests' library not installed — skipping push.",
            stacklevel=2,
        )
        return False

    try:
        print(f"  📡 [NucleusPush] Pushing {target_week} → {api_url}")
        resp = requests.post(api_url, json=payload, timeout=15)
        resp.raise_for_status()
        print(f"  ✅ [NucleusPush] Push successful — HTTP {resp.status_code}")
        return True
    except requests.RequestException as exc:
        warnings.warn(
            f"[NucleusPush] POST failed: {exc}. Skipping.",
            stacklevel=2,
        )
        return False


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    push_to_nucleus()
