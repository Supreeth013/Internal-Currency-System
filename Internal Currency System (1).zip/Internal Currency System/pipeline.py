"""
Pipeline — Main Entry Point
============================
Runs all agents in sequence:
    1. aw_raw_parser   (via parser_agent)
    2. base_points_agent
    3. bonus_points_agent
    4. attendance_agent
    5. aggregator_agent
    6. nucleus_push_agent

Usage:
    python pipeline.py --week 2026-05-09
    python pipeline.py --week 2026-05-09 --input data/input/export.json
    python pipeline.py --week 2026-05-09 --folder data/input/
"""

import argparse
import sys
import traceback
from pathlib import Path
from typing import Dict, List

from models import ActivityRecord, StudentScore

# ---------------------------------------------------------------------------
# Agent imports
# ---------------------------------------------------------------------------

from agents.parser_agent import parse_file
from agents.base_points_agent import calculate_base_score
from agents.bonus_points_agent import apply_bonus
from agents.attendance_agent import apply_attendance_all
from agents.aggregator_agent import aggregate
from agents.nucleus_push_agent import push_to_nucleus


DEFAULT_INPUT = Path(__file__).resolve().parent / "data" / "input"


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------


def run_pipeline(week: str, input_files: List[str]) -> None:
    """Execute the full mining pipeline for the given week."""

    print("\n" + "=" * 60)
    print("  ⛏️  NUCLEUS MINING PIPELINE")
    print(f"  Week ending: {week}")
    print(f"  Input files: {len(input_files)}")
    print("=" * 60 + "\n")

    all_records: List[ActivityRecord] = []
    all_flagged: Dict[str, List[str]] = {}

    # ------------------------------------------------------------------
    # STEP 1 — Parse AW exports
    # ------------------------------------------------------------------
    print("▶ STEP 1: Parsing ActivityWatch exports...")
    for fpath in input_files:
        try:
            records, flagged = parse_file(fpath, week=week)
            all_records.extend(records)
            all_flagged.update(flagged)
            print(f"    ✔ {Path(fpath).name} → {len(records)} day(s)")
        except Exception as exc:
            print(f"    ✖ {Path(fpath).name} — ERROR: {exc}")
            traceback.print_exc()

    # If week filter produced nothing, retry without filter
    if not all_records and week:
        print("    ⚠ No records matched the week filter. Retrying without filter...")
        for fpath in input_files:
            try:
                records, flagged = parse_file(fpath, week=None)
                all_records.extend(records)
                all_flagged.update(flagged)
                print(f"    ✔ {Path(fpath).name} → {len(records)} day(s)")
            except Exception as exc:
                print(f"    ✖ {Path(fpath).name} — ERROR: {exc}")
                traceback.print_exc()

    if not all_records:
        print("\n  ⚠ No activity records found. Pipeline complete.\n")
        return

    print(f"    Total records: {len(all_records)}\n")

    # ------------------------------------------------------------------
    # STEP 2 — Base points
    # ------------------------------------------------------------------
    print("▶ STEP 2: Calculating base points...")
    scores: List[StudentScore] = []
    for rec in all_records:
        try:
            score = calculate_base_score(rec)
            scores.append(score)
        except Exception as exc:
            print(f"    ✖ {rec.student_id}/{rec.date} — ERROR: {exc}")
            traceback.print_exc()
    print(f"    Scored {len(scores)} record(s)\n")

    # ------------------------------------------------------------------
    # STEP 3 — Bonus points
    # ------------------------------------------------------------------
    print("▶ STEP 3: Applying bonus points...")
    try:
        from agents.bonus_points_agent import apply_bonus_all
        scores = apply_bonus_all(scores)
        print("    ✔ Bonus points applied\n")
    except Exception as exc:
        print(f"    ✖ Bonus agent error: {exc}\n")
        traceback.print_exc()

    # ------------------------------------------------------------------
    # STEP 4 — Attendance rules
    # ------------------------------------------------------------------
    print("▶ STEP 4: Applying attendance rules...")
    try:
        scores = apply_attendance_all(scores)
        print("    ✔ Attendance rules applied\n")
    except Exception as exc:
        print(f"    ✖ Attendance agent error: {exc}\n")
        traceback.print_exc()

    # ------------------------------------------------------------------
    # STEP 5 — Aggregate & export
    # ------------------------------------------------------------------
    print("▶ STEP 5: Aggregating results...")
    try:
        paths = aggregate(week, scores, all_flagged)
    except Exception as exc:
        print(f"    ✖ Aggregator error: {exc}\n")
        traceback.print_exc()

    # ------------------------------------------------------------------
    # STEP 6 — Nucleus push
    # ------------------------------------------------------------------
    print("▶ STEP 6: Pushing to Nucleus API...")
    try:
        push_to_nucleus(week_ending=week)
    except Exception as exc:
        print(f"    ✖ Nucleus push error: {exc}\n")
        traceback.print_exc()

    print("=" * 60)
    print("  ✅ PIPELINE COMPLETE")
    print("=" * 60 + "\n")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main():
    parser = argparse.ArgumentParser(
        description="Nucleus Mining Pipeline — process ActivityWatch exports"
    )
    parser.add_argument(
        "--week",
        required=True,
        help="Week-ending Friday date (YYYY-MM-DD), e.g. 2026-05-09",
    )
    parser.add_argument(
        "--input",
        default=None,
        help="Path to a single AW JSON export file",
    )
    parser.add_argument(
        "--folder",
        default=str(DEFAULT_INPUT),
        help="Folder containing AW JSON exports (default: data/input/)",
    )
    args = parser.parse_args()

    # Collect input files
    if args.input:
        input_files = [args.input]
    else:
        folder = Path(args.folder)
        input_files = sorted(
            str(f) for f in folder.glob("*.json")
            if f.name not in ("bonus_input.json", "medical_exceptions.json")
        )

    if not input_files:
        print("  ⚠ No JSON files found in", args.folder)
        sys.exit(1)

    run_pipeline(args.week, input_files)


if __name__ == "__main__":
    main()
